<?php

require_once('conexion.php');

$sql = "SELECT tclie_idclie, tclie_identc, tclie_namecl, tclie_telecl, tclie_emailc, tclie_cedrif FROM tclic_tme;";
$clientes = $conexion->query($sql);

require_once 'validations/Formulario.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/all.min.css" rel="stylesheet">
    <link href="assets/images/favicon.png" rel="icon">
    <link href="assets/images/favicon.png" rel="apple-touch-icon">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <!-- ========================================================= -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <script>
      const modulo = "moduloclientes";
      const modaltitle = "cliente";
    </script>
</head>
<body>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Clientes</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
            
    <div class="col-auto mb-3">
        <a href="#" id="new" class="btn btn-primary" data-bs-toggle="modal"><i class="fa-solid fa-circle-plus"></i> Nuevo Cliente</a>
    </div>

          <div class="card">
            <!-- /.card-header -->
            <div class="data_table card-body table-responsive">
            <table id="example" class="table table-sm table-striped table-hover mt-4">
        <thead class="table-dark">
            <tr>
                <th>Id</th>
                <th>Identificacion</th>
                <th>Nombre</th>
                <th>Telefono</th>
                <th>Correo electronico</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php while($row_clientes = $clientes->fetch_assoc()){ ?>
               <tr>
                 <td><?= $row_clientes['tclie_idclie'] ?></td>

                 <?php if($row_clientes['tclie_cedrif'] == 'V'): ?>

                 <td><?= $row_clientes['tclie_cedrif'] . "-" .number_format($row_clientes['tclie_identc'], 0, ",", ".") ?></td>

                 <?php else: ?>

                  <td><?= $row_clientes['tclie_cedrif'] . "-" .$row_clientes['tclie_identc'] ?></td>

                 <?php endif; ?>
                 <td><?= $row_clientes['tclie_namecl'] ?></td>
                 <td><?= $row_clientes['tclie_telecl'] ?></td>
                 <td><?= $row_clientes['tclie_emailc'] ?></td>
                 <td>

                  <a href="#" id="edit" class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#nuevoModal" onclick="edit(<?= $row_clientes['tclie_idclie']; ?>)"><i class="fa-solid fa-pencil"></i> Editar</a>


                 </td>
               </tr>

           <?php } ?>
</tbody>

        </tbody>
    </table>

            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

    <?php

    ?>

    <?php
    include 'nuevoModal.php';
    include 'eliminaModal.php';
    ?>

    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/datatables.min.js"></script>

    <script>
      $(document).ready(function(){
    
    var table = $('#example').DataTable({

        responsive: true,
        
        buttons:['copy',  'excel', 'pdf', 'print'],

        "language": {
            "processing": "Procesando...",
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "No se encontraron resultados",
            "emptyTable": "Ningún dato disponible en esta tabla",
            "info": "Mostrando la pagina _PAGES_ de _PAGES_",
            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "search": "Buscar:",
            "loadingRecords": "Cargando...",
            "paginate": {
            "first": "Primero",
            "last": "Último",
            "next": "Siguiente",
            "previous": "Anterior"
        },
          }  
    });
    
    table.buttons().container()
    .appendTo('#example_wrapper .col-md-6:eq(0)');

});

    </script>


    <script>

$('#cedula').prop('name', 'cedulaHidden');

  $('#tiprif').change(
    function(){
      $('.ident').val('');
    if ($('#tiprif').val()=="V") {
      $('.ident').prop('name', 'cedula');
      $('.ident').prop('id', 'cedula');
      $('.ident').prop('placeholder', '15862175');
      $('#grupo__rif').prop('id', 'grupo__cedula');
      $('#errormsg').text('La identificacion debe poseer 7 u 8 digitos');
    }else{
      $('.ident').prop('name', 'rif');
      $('.ident').prop('id', 'rif');
      $('#grupo__cedula').prop('id', 'grupo__rif');
      $('.ident').prop('placeholder', '407898280');
      $('#errormsg').text('La identificacion debe poseer 9 digitos');
    }
  })

     let editaModal = document.getElementById('nuevoModal')
     let eliminaModal = document.getElementById('eliminaModal')

    function edit(val) {
        let id = val;
        validRefresh();
        openEdit();

        let inputId = editaModal.querySelector('.modal-body #id')
        let inputCedrif = editaModal.querySelector('.modal-body #tiprif')
        let inputIdentificacion = editaModal.querySelector('.modal-body .ident')
        let inputCedrifOld = editaModal.querySelector('.modal-body #tiprifOld')
        let inputIdentificacionHide = editaModal.querySelector('.modal-body #rifOld')
        let inputNombre = editaModal.querySelector('.modal-body #nombre')
        let inputTelefono = editaModal.querySelector('.modal-body #telefono')
        let inputCorreo = editaModal.querySelector('.modal-body #correo')
        let inputCorreoHide = editaModal.querySelector('.modal-body #correoOld')
        let inputDir = editaModal.querySelector('.modal-body #direccion')
        

        let url = "moduloclientes/getMoneda.php"
        let formData = new FormData()
        formData.append('id', id)

        fetch(url, {
            method: "POST",
            body: formData
        }).then(response => response.json())
        .then(data => {

            inputId.value = data.tclie_idclie
            inputCedrif.value = data.tclie_cedrif
            inputIdentificacion.value = data.tclie_identc
            inputCedrifOld.value = data.tclie_cedrif
            inputIdentificacionHide.value = data.tclie_identc
            inputNombre.value = data.tclie_namecl
            inputTelefono.value = data.tclie_telecl
            inputCorreo.value = data.tclie_emailc
            inputCorreoHide.value = data.tclie_emailc
            inputDir.value = data.tclie_direcl

            if (inputCedrif.value=="V") {

            $('.ident').prop('name', 'cedula');
            $('.ident').prop('id', 'cedula');
            $('.ident').prop('placeholder', '15862175');
            $('#grupo__rif').prop('id', 'grupo__cedula');
            $('#errormsg').text('La identificacion debe poseer 7 u 8 digitos');
          }else{


            $('.ident').prop('name', 'rif');
            $('.ident').prop('id', 'rif');
            $('#grupo__cedula').prop('id', 'grupo__rif');
            $('.ident').prop('placeholder', '407898280');
            $('#errormsg').text('La identificacion debe poseer 9 digitos');
          }
            
        }).catch(err => console.log(err))

     }
     eliminaModal.addEventListener('shown.bs.modal', event => {
        let button = event.relatedTarget
        let id = button.getAttribute('data-bs-id')
        eliminaModal.querySelector('.modal-footer #id').value = id
     })
    </script>

<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>