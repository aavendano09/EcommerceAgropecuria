<?php

date_default_timezone_set("America/Caracas");

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'kevin9570');
define('DB_DATABASE', 'ecommerce_agropecuaria');
define('NUM_ITEMS_BY_PAGE', 8);

//$conexion = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
?>